#!/usr/bin/env python3

# MIT License
#
# Copyright (c) 2021 Eugenio Parodi <ceccopierangiolieugenio AT googlemail DOT com>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Demo inspired from:
# https://stackoverflow.com/questions/41204234/python-pyqt5-qtreewidget-sub-item

import os
import sys
import random
import argparse

sys.path.append(os.path.join(sys.path[0],'../../libs/pyTermTk'))
import TermTk as ttk

sys.path.append(os.path.join(sys.path[0],'..'))
from showcase._showcasehelper import getUtfSentence, getUtfWord

def demoFancyTree(root=None):
    # tw = ttk.TTkFancyTreeWidget(parent=rootTree1)
    tw = ttk.TTkFancyTree(parent=root)
    tw.setHeaderLabels(["Column 1", "Column 2", "Column 3"])
    tw.setColumnSize((-1,20,20))
    tw.setColumnColors((
            ttk.TTkColor.RST,
            ttk.TTkColor.fg('#00dddd', modifier=ttk.TTkColorGradient(increment=-4)),
            ttk.TTkColor.fg('#cccc00', modifier=ttk.TTkColorGradient(increment=-2))
        ))
    l1   = ttk.TTkFancyTreeWidgetItem(["String A", "String B", "String C"])
    l2   = ttk.TTkFancyTreeWidgetItem(["String AA", "String BB", "String CC"])
    l3   = ttk.TTkFancyTreeWidgetItem(["String AAA", "String BBB", "String CCC"])
    l4   = ttk.TTkFancyTreeWidgetItem(["String AAAA", "String BBBB", "String CCCC"])
    l5   = ttk.TTkFancyTreeWidgetItem(["String AAAAA", "String BBBBB", "String CCCCC"])

    l2.addChild(l5)

    for i in range(3):
        l1_child = ttk.TTkFancyTreeWidgetItem(["Child A" + str(i), "Child B" + str(i), "Child C" + str(i)])
        l1.addChild(l1_child)

    for j in range(2):
        l2_child = ttk.TTkFancyTreeWidgetItem(["Child AA" + str(j), "Child BB" + str(j), "Child CC" + str(j)])
        l2.addChild(l2_child)

    for j in range(2):
        l3_child = ttk.TTkFancyTreeWidgetItem(["Child AAA" + str(j), "Child BBB" + str(j), "Child CCC" + str(j)])
        l3.addChild(l3_child)

    for j in range(2):
        l4_child = ttk.TTkFancyTreeWidgetItem(["Child AAAA" + str(j), "Child BBBB" + str(j), "Child CCCC" + str(j)])
        l4.addChild(l4_child)

    for j in range(2):
        l5_child = ttk.TTkFancyTreeWidgetItem(["Child AAAAA" + str(j), "Child BBBBB" + str(j), "Child CCCCC" + str(j)])
        l5.addChild(l5_child)

    l6   = ttk.TTkFancyTreeWidgetItem(["RND", "RND", "RND"], childIndicatorPolicy=ttk.TTkK.ShowIndicator)

    def updateChildren(item):
        if item.children(): return
        for _ in range(0,random.randint(3,8)):
            child = ttk.TTkFancyTreeWidgetItem([getUtfWord(),getUtfWord(),getUtfWord()])
            if random.randint(0,10)>5:
                child.setChildIndicatorPolicy(ttk.TTkK.ShowIndicator)
                child.refreshData.connect(updateChildren)
            item.addChild(child)


    l6.refreshData.connect(updateChildren)

    tw.addTopLevelItem(l1)
    tw.addTopLevelItem(l2)
    tw.addTopLevelItem(l3)
    tw.addTopLevelItem(l4)
    tw.addTopLevelItem(l6)

    return tw

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', help='Full Screen', action='store_true')
    args = parser.parse_args()

    root = ttk.TTk()
    if args.f:
        rootTree1 = root
        root.setLayout(ttk.TTkGridLayout())
    else:
        rootTree1 = ttk.TTkWindow(parent=root,pos = (0,0), size=(70,40), title="Test Tree 1", layout=ttk.TTkGridLayout(), border=True)
    demoFancyTree(rootTree1)
    root.mainloop()

if __name__ == "__main__":
    main()