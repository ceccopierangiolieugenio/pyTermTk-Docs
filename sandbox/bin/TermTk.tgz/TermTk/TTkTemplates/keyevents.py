# MIT License
#
# Copyright (c) 2021 Eugenio Parodi <ceccopierangiolieugenio AT googlemail DOT com>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

__all__ = ['TKeyEvents']

from TermTk.TTkCore.TTkTerm.inputkey import TTkKeyEvent

class TKeyEvents():
    def __init__(self) -> None: pass

#    def keyPressEvent(self, evt:TTkKeyEvent) -> bool:
#        '''
#        This event handler, can be reimplemented in a subclass to receive key press events for the widget.
#
#        .. note:: Reimplement this function to handle this event
#
#        :param evt: The keyboard event
#        :type evt: :py:class:`TTkKeyEvent`
#
#        :return: **True** if the event has been handled
#        :rtype: bool
#        '''
#        return False
#    def keyReleaseEvent(self, evt:TTkKeyEvent) -> bool:
#        '''
#        This event handler, can be reimplemented in a subclass to receive key release events for the widget.
#
#        .. note:: Reimplement this function to handle this event
#
#        :param evt: The keyboard event
#        :type evt: :py:class:`TTkKeyEvent`
#
#        :return: **True** if the event has been handled
#        :rtype: bool
#        '''
#        return False

    def keyEvent(self, evt:TTkKeyEvent) -> bool:
        '''
        This event handler, can be reimplemented in a subclass to receive key events for the widget.

        .. note:: Reimplement this function to handle this event

        The received event is a :py:class:`TTkKeyEvent_Character` for literal
        text input or a :py:class:`TTkKeyEvent_SpecialKey` for translated
        terminal sequences such as arrows, Enter, or function keys.

        :param evt: The keyboard event.
        :type evt: :py:class:`TTkKeyEvent`

        :return: **True** if the event has been handled.
        :rtype: bool
        '''
        return False
